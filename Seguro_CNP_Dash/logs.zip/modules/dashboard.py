# Página do dashboard

from dash import html

layout = html.Div([
    html.H3("Dashboard - Em construção")
])
